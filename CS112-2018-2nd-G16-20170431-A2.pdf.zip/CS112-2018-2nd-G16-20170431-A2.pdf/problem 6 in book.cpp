#include <iostream>
using namespace std;

double num__family, num__Hworks ;

void num_family()
{

    if (num__family>=3)
    {
        num__Hworks=num__Hworks+35;
        cout<<"Now your account is : "<<num__Hworks;
    }
    else
        cout<<"Okay your current account is : " << num__Hworks;
}

void num_Hwork()
{


    if (num__Hworks<0)
    {
        cout<<"error";
    }
    else
    {
        if (num__Hworks>=40)
        {
            num__Hworks=((num__Hworks*16.78)*1.5);
            cout<<"your account is : "<<num__Hworks<<endl;
        }
        else if (num__Hworks<40)
        {
            num__Hworks=(num__Hworks*16.78);
            cout<<"your main account is : "<<num__Hworks<<endl;
        }
        else
        {
            cout<< "error" ;
        }
    }
}

int main()
{

    cout<<"num of your family \n";
    cin>>num__family;

    cout<<"num of hours you works ";
    cin>>num__Hworks;
    num_Hwork();

    num__Hworks=(num__Hworks*25)/100;
    cout<<"after taxs is : "<<num__Hworks<<endl;

    num_family();

    return 0;
}
