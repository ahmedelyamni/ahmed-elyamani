#include <iostream>
using namespace std;

string word ;
int num, change , choise , y =0, j=0;

void encryption()
{

    while (j<word.length())
    {

        if (int(word[j]+num)>122){
            y=26-num;
            change = 122 - y;
            cout<<(char) (change);

        }
      else{

        change = word[j]+num;

        cout<<(char) (change);
    }
     j++;
    }

}

void decrypt()
{
    while (j<word.length())
    {

        if ((int(word[j])-num )<97){
            y=97-(int(word[j]-num));
            change = 123 - y;
            cout<<(char) (change);

        }
      else{

        change = word[j]-num;

        cout<<(char) (change);
    }
     j++;
    }


}

int main()
{
    cout<<"if you want to encryption press 1 or press 2 for decrypt \n";
    cin>>choise;
    cout<<"enter the word \n";
    cin>>word;
    cout<<"enter num of shift \n";
    cin>>num;

    if (choise==1){
        encryption();
    }
    else if (choise==2){
        decrypt();
    }
    else{
        cout<<"error";

    }
    return 0;
}
