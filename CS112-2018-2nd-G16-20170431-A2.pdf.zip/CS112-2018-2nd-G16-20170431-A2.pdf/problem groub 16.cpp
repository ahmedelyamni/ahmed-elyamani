#include <iostream>
#include <cstring>
#include <ctype.h>

using namespace std;

int main()
{
    char ch ;
    string day ;
    int minut ;
    double time,test ;
    string arr[7]= {"sa", "su", "mo", "tu", "we", "th", "fr"};

    do
    {

        cout<<"enter the day of the call \n";
        cin>>day;
        cout<<"enter the time of your call \n";
        cin>>time;
        cout<<"enter num of minuts \n";
        cin>>minut;


        for( int i=0 ; i<day.length()  ; i++ )
        {
            day[i] = tolower(day[i]);
        }

        if (time >12)
        {
            time= time - 12;
            if (day==arr[5] || day==arr[6] || day==arr[2] || day==arr[3] || day==arr[4] )
            {
                if( time >=8 && time <=18  )
                {
                    test= minut* 0.40;
                    cout<<test<<"$ \n ";
                }
                else if(time <=24 || time > 18 || time <8 || time >=0.1 )
                {

                    test = minut*0.25;
                    cout<<test<<" $ \n ";
                }
                else
                {
                    cout<<"the time is wrong";
                }
            }
            else if ( day==arr[0] || day==arr[1] )
            {
                test = minut *0.25;
                cout<<test<<" $ \n ";
            }
            else
                cout<<"errror";

        }
        else
        {
            if (day==arr[5] || day==arr[6] || day==arr[2] || day==arr[3] || day==arr[4] )
            {
                if( time >=8 && time <=18  )
                {
                    test= minut * 0.40;
                    cout<<test<<" $ \n ";

                }
                if(time <=24 && time > 18 && time <8 && time >=0.1 )

                {

                    test = minut *0.25;
                    cout<<test<<" $ \n ";
                }
            }

            if ( day==arr[0] || day==arr[1] )
            {



                test = minut *0.25;
                cout<<test<<" $ \n ";


            }

            else
            {
                cout<<"error";

            }
        }

        cout << " if you want to Do it again press \" y \" if not press \" n \" " << endl ;
        cin >> ch  ;
    }
    while(ch == 'y' || ch =='Y');

    return 0;
}
