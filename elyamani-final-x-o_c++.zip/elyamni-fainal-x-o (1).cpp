
#include <iostream>
#include <cstdlib>///cls
using namespace std;
int count =0 ;

char matrix[3][3]= { '1','2','3','4','5','6','7','8','9' };

bool is_Win ()
{
    if(matrix[0][0]=='x' && matrix[0][1]=='x' && matrix[0][2]=='x' )
        {
        return true ;
     }
    if(matrix[1][0]=='x' && matrix[1][1]=='x' && matrix[1][2]=='x' )
    {
        return true ;
    }
    if(matrix[2][0]=='x' && matrix[2][1]=='x' && matrix[2][2]=='x' )
    {
        return true ;
    }
    if(matrix[0][0]=='x' && matrix[1][0]=='x' && matrix[2][0]=='x' )
    {
        return true ;
    }
    if(matrix[0][1]=='x' && matrix[1][1]=='x' && matrix[2][1]=='x' )
    {
        return true ;
    }
    if(matrix[0][2]=='x' && matrix[1][2]=='x' && matrix[2][2]=='x' )
    {
        return true ;
    }
    if(matrix[0][2]=='x' && matrix[1][1]=='x' && matrix[2][0]=='x' )
    {
        return true ;
    }
    if(matrix[0][0]=='x' && matrix[1][1]=='x' && matrix[2][2]=='x' )
    {
        return true ;
    }
    return false ;
}


bool is_Win2 ()
{
    if(matrix[0][0]=='o' && matrix[0][1]=='o' && matrix[0][2]=='o' )
    {
        return true ;
    }
    if(matrix[1][0]=='x' && matrix[1][1]=='x' && matrix[1][2]=='x' )
    {
        return true ;
    }
    if(matrix[2][0]=='x' && matrix[2][1]=='x' && matrix[2][2]=='x' )
    {
        return true ;
    }
    if(matrix[0][0]=='x' && matrix[1][0]=='x' && matrix[2][0]=='x' )
    {
        return true ;
    }
    if(matrix[0][1]=='x' && matrix[1][1]=='x' && matrix[2][1]=='x' )
    {
        return true ;
    }
    if(matrix[0][2]=='x' && matrix[1][2]=='x' && matrix[2][2]=='x' )
    {
        return true ;
    }
    if(matrix[0][2]=='x' && matrix[1][1]=='x' && matrix[2][0]=='x' )
    {
        return true ;
    }
    if(matrix[0][0]=='x' && matrix[1][1]=='x' && matrix[2][2]=='x' )
    {
        return true ;
    }
    return false ;
}


void display()
{

    system ("cls");///system ("clear");

    for(int i=0 ; i<3 ; ++i)  // rows
    {
        for (int j=0 ; j<3 ; ++j)  // col
        {

            cout << matrix[i][j] << "  ";
        }
        cout<<endl;
    }
}

void found_Position (char op, int & row, int & col   )
{
    if(op == '1')
    {
        row = 0 ;
        col = 0 ;
    }

    else if(op == '2')
    {
        row = 0 ;
        col = 1 ;
    }
    else if(op == '3')
    {
        row = 0 ;
        col = 2 ;
    }
    else if(op == '4')
    {
        row = 1 ;
        col = 0 ;
    }
    else if(op == '5')
    {
        row = 1 ;
        col = 1 ;
    }
    else if(op == '6')
    {
        row = 1 ;
        col = 2 ;
    }
    else if(op == '7')
    {
        row = 2 ;
        col = 0 ;
    }
    else if(op == '8')
    {
        row = 2 ;
        col = 1 ;
    }
    else if(op == '9')
    {
        row = 2 ;
        col = 2 ;
    }


}
int main()
{
    char ch ;

    int row = 0, col = 0 ;


    while (true)
    {


        display();

        if(count %2 == 0)
        {

            cout << "Player 1 :"  ;

            cin >> ch ;

            found_Position (ch, row, col);

            matrix[row][col] = 'x';



            display();
             if(count==8)
                {
                    cout<<"draw";
                    return 0;
                     break;
                }


            if(is_Win())
            {
                cout<<"Player1 win" << endl;

            }

        }

        else
        {


            cout << "Player 2 :"  ;
            cin >> ch ;


            found_Position (ch, row, col);

            matrix[row][col] = 'o';



            display();
             if(count==8)
                {
                    cout<<"draw";
                    return 0;
                     break;
                }


            if(is_Win2())
            {
                cout<<"Player2 win" << endl;

            }

        }

        count ++ ;

    }
    return 0;
}
